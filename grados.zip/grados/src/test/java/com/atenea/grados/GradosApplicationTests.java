package com.atenea.grados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradosApplicationTests {

	@Test
	void contextLoads() {
	}

}

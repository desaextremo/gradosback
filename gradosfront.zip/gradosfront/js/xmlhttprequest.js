//obtener referencia a la caja de texto
let cajaTemperatura = document.getElementById("temperatura")
//ubica el cursor o foco en la caja de texto
cajaTemperatura.focus()

//obtener referencia a la lista de opciones para convertir temperatura
let listaOpciones = document.getElementById("listaOpciones")

//obtener referencia al boton
let botonAceptar = document.getElementById("botonAceptar")

//obtener referencia al titulo de resultados
let tituloResultado = document.getElementById("tituloResultado");

//obtener referencia al mensaje de resultados
let mensajeResultado = document.getElementById("mensajeResultado");

//definir oyente de eventos de clic sobre el boton
botonAceptar.addEventListener("click", procesarTemperatura)

//Funcion encargda de invocar servicio we para realizar el calculo de temperatura
//según la opción seleccionada en la lista 'listaOpciones'
function procesarTemperatura() {
    //variable para establecer la utl del servicio a invocar
    let url = ""
    //variable para establecer el titulo de la respuesta
    let titulo = ""
    //variable para capturar la cantidad de grados
    let grados = cajaTemperatura.value

    //lee el valor de  la opcion de conversion de temperatura seleccionada en la lista
    let opcionSeleccionada = listaOpciones.value

    if (opcionSeleccionada == 1) {
        //alert("Centigrados a Farenheit")
        titulo = "Centigrados a Farenheit"
        url = "http://localhost:8080/grados/centofarenh/" + grados
    } else if (opcionSeleccionada == 2) {
        //alert("Farenheit a Centigrados")
        titulo = "Farenheit a Centigrados"
        url = "http://localhost:8080/grados/farenhyocent/" + grados
    } else if (opcionSeleccionada == 3) {
        //alert("Centigrados a Kelvin")
        titulo = "Centigrados a Kelvin"
        url = "http://localhost:8080/grados/centokelvin/" + grados
    } else if (opcionSeleccionada == 4) {
        //alert("Kelvin a Centigrados")
        titulo = "Kelvin a Centigrados"
        url = "http://localhost:8080/grados/kelvintocent/" + grados
    }

    //peticion al servicio web
    //1 Crear objeto XMLHttpRequest
    let peticion = new XMLHttpRequest();

    //2 Controlar envio de la peticion   
    peticion.onreadystatechange = function () {
        //si el servidor ya entrego respuesta y esta fue positiva
        if (this.readyState == 4 && this.status == 200) {
            //configura el titulo del h2
            tituloResultado.innerHTML = titulo
            //Obtiene respuesta y la agrega a la sección de la pagina
            mensajeResultado.innerHTML = this.responseText;
        }
    };

    //3 configurar envio de la petición   
    peticion.open(
        "GET",
        url,
        true
    );

    //4 Enviar la peticion
    peticion.send();
}